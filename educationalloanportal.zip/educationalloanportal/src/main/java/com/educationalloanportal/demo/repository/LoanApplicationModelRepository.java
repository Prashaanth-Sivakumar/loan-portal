package com.educationalloanportal.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.educationalloanportal.demo.model.LoanApplicationModel;

public interface LoanApplicationModelRepository extends JpaRepository<LoanApplicationModel,Integer>{

}
