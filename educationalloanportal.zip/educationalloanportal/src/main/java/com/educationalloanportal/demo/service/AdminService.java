package com.educationalloanportal.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.educationalloanportal.demo.model.AdminModel;
import com.educationalloanportal.demo.model.LoanApplicationModel;
import com.educationalloanportal.demo.repository.AdminModelRepository;
import com.educationalloanportal.demo.repository.LoanApplicationModelRepository;

@Service
public class AdminService {
	@Autowired
	AdminModelRepository aRepository;
	@Autowired
	LoanApplicationModelRepository laRepository;
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public List<AdminModel> getDetails() {
		List<AdminModel> dataList=aRepository.findAll();
		return  dataList;
	}

	public AdminModel searchDetails(String email) {
		return aRepository.findById(email).get();
	}

	public AdminModel saveDetails(AdminModel a) {
		return aRepository.save(a);
	}

	public AdminModel updateDetails(AdminModel a, String email) {
		Optional <AdminModel> optional=aRepository.findById(email);
		AdminModel obj=null;
		if(optional.isPresent()){
			return aRepository.save(a);
		}
		return obj;
	}

	public void deleteDetails(String email) {
		aRepository.deleteById(email);
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public List<LoanApplicationModel> getLoanDetails() {
		List<LoanApplicationModel> dataList=laRepository.findAll();
		return  dataList;
	}

	public LoanApplicationModel searchLoanDetails(int loanId) {
		return laRepository.findById(loanId).get();
	}

	public LoanApplicationModel saveLoanDetails(LoanApplicationModel la) {
		return laRepository.save(la);
	}
 
	public LoanApplicationModel updateLoanDetails(LoanApplicationModel la, int loanId) {
		Optional <LoanApplicationModel> optional=laRepository.findById(loanId);
		LoanApplicationModel obj=null;
		if(optional.isPresent()){
			return laRepository.save(la);
		}
		return obj;
	}

	public void deleteLoanDetails(int loanId) {
		laRepository.deleteById(loanId);
	}
}
