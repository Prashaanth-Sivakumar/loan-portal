package com.educationalloanportal.demo.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.educationalloanportal.demo.model.LoginModel;
import com.educationalloanportal.demo.model.UserModel;
import com.educationalloanportal.demo.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;



@RestController
public class UserController {

	@Autowired
	UserService uService;
	////////////////////////////////////////////// Login Details  ////////////////////////////////////////////
	
	@Operation(summary = "Get all the Items")
	
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Items data fetched successfully"),
			
			@ApiResponse(responseCode = "401", description = "Invalid credentials"),
			
			@ApiResponse(responseCode = "404", description = "Path not found") })
	
	@GetMapping("/getLoginDetails")
	public List<LoginModel> getLoginDetails(){
		List<LoginModel> loginList=uService.getLoginDetails();
		return loginList;
	}
	
	@GetMapping("/searchLoginDetails/{userId}")
	public UserModel searchLoginDetails(@PathVariable("userId") int id){
		return uService.searchLoginDetails(id);
	}
	
	@Operation(summary = "Creates a new Item")

	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Item created successfully"),

			@ApiResponse(responseCode = "400", description = "Item is invalid"),

			@ApiResponse(responseCode = "401", description = "Invalid credentials") })

	@ResponseStatus(HttpStatus.CREATED)
	
	@PostMapping("/saveLoginDetails")
	public LoginModel saveLoginDetails(@RequestBody LoginModel l) {
		return uService.saveLoginDetails(l);
	}
	
	@PutMapping("/updateLoginDetails/{userId}")
	public UserModel updateLoginDetails(@RequestBody UserModel u,@PathVariable int userId) {
		return uService.updateLoginDetails(u,userId);
	}
	
	@DeleteMapping("/deleteLoginDetails/{userId}")
	public void deleteLoginDetails(@PathVariable("userId") int id){
		uService.deleteLoginDetails(id);
	}
	
	/////////////////////////////////////////// USER DETAILS /////////////////////////////////////////////////////
	
	
	@GetMapping("/getUserDetails")
	public List<UserModel> getUserDetails(){
		List<UserModel> userList=uService.getUserDetails();
		return userList;
	}
	
	@GetMapping("/searchUserDetails/{userId}")
	public UserModel searchUserDetails(@PathVariable("userId") int id){
		return uService.searchUserDetails(id);
	}
	
	@PostMapping("/saveUserDetails")
	public UserModel saveUserDetails(@RequestBody UserModel u) {
		return uService.saveUserDetails(u);
	}
	
	@PutMapping("/updateUserDetails/{userId}")
	public UserModel updateUserDetails(@RequestBody UserModel u,@PathVariable int userId) {
		return uService.updateUserDetails(u,userId);
	}
	
	@DeleteMapping("/deleteUserDetails/{userId}")
	public void deleteUserDetails(@PathVariable("userId") int id){
		uService.deleteUserDetails(id);
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
