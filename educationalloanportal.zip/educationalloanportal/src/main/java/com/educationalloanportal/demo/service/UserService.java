package com.educationalloanportal.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.educationalloanportal.demo.model.LoginModel;
import com.educationalloanportal.demo.model.UserModel;
import com.educationalloanportal.demo.repository.LoginModelRepository;
import com.educationalloanportal.demo.repository.UserModelRepository;


@Service
public class UserService {

	@Autowired
	LoginModelRepository lRepository;
	@Autowired
	UserModelRepository uRepository;
	
	//////////////////////////////////////////////Login Details  ////////////////////////////////////////////
	public List<LoginModel> getLoginDetails() {
		List<LoginModel> loginList=lRepository.findAll();
		return  loginList;
	}
	
	public UserModel searchLoginDetails(int id) {
		return uRepository.findById(id).get();
	}

	public LoginModel saveLoginDetails(LoginModel l) {
		return lRepository.save(l);
	}

	public UserModel updateLoginDetails(UserModel u, int userId) {
		Optional <UserModel> optional=uRepository.findById(userId);
		UserModel obj=null;
		if(optional.isPresent()){
			return uRepository.save(u);
		}
		return obj;
	}

	public void deleteLoginDetails(int id) {
		uRepository.deleteById(id);
		
	}

	/////////////////////////////////////////// USER DETAILS /////////////////////////////////////////////////////
	public List<UserModel> getUserDetails() {
		List<UserModel> userList=uRepository.findAll();
		return  userList;
	}

	public UserModel searchUserDetails(int id) {
		return uRepository.findById(id).get();
	}

	public UserModel saveUserDetails(UserModel u) {
		return uRepository.save(u);
	}

	public UserModel updateUserDetails(UserModel u, int userId) {
		Optional <UserModel> optional=uRepository.findById(userId);
		UserModel obj=null;
		if(optional.isPresent()){
			return uRepository.save(u);
		}
		return obj;
	}

	public void deleteUserDetails(int id) {
		uRepository.deleteById(id);
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
