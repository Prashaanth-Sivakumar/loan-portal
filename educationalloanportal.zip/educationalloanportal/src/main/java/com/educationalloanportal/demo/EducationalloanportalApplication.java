package com.educationalloanportal.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducationalloanportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducationalloanportalApplication.class, args);
		System.out.println("Mondainai");
	}

}
