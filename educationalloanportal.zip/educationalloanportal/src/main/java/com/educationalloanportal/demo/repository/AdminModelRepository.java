package com.educationalloanportal.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.educationalloanportal.demo.model.AdminModel;

public interface AdminModelRepository extends JpaRepository<AdminModel,String>{

}
