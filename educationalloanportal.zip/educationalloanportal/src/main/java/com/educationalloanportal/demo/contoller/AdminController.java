package com.educationalloanportal.demo.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.educationalloanportal.demo.model.AdminModel;
import com.educationalloanportal.demo.model.LoanApplicationModel;
import com.educationalloanportal.demo.service.AdminService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class AdminController {
	@Autowired
	AdminService aService;
	
////////////////////////////////////////////// admin Details  ////////////////////////////////////////////

	@Operation(summary = "Get all the Items")
	
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Items data fetched successfully"),
			
			@ApiResponse(responseCode = "401", description = "Invalid credentials"),
			
			@ApiResponse(responseCode = "404", description = "Path not found") })
	
	@GetMapping("/getDetails")
	public List<AdminModel> getDetails(){
		List<AdminModel> dataList=aService.getDetails();
		return dataList;
	}
	
	@GetMapping("/searchDetails/{emailId}")
	public AdminModel searchUserDetails(@PathVariable("emailId") String email){
		return aService.searchDetails(email);
	}
	

	@Operation(summary = "Creates a new Item")

	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Item created successfully"),

			@ApiResponse(responseCode = "400", description = "Item is invalid"),

			@ApiResponse(responseCode = "401", description = "Invalid credentials") })

	@ResponseStatus(HttpStatus.CREATED)
	
	@PostMapping("/saveDetails")
	public AdminModel saveDetails(@RequestBody AdminModel a) {
		return aService.saveDetails(a);
	}
	
	@PutMapping("/updateDetails/{emailId}")
	public AdminModel updateDetails(@RequestBody AdminModel a,@PathVariable String emailId) {
		return aService.updateDetails(a,emailId);
	}
	
	@DeleteMapping("/deleteDetails/{emailId}")
	public void deleteDetails(@PathVariable("emailId") String email){
		aService.deleteDetails(email);
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@GetMapping("/getLoanDetails")
	public List<LoanApplicationModel> getLoanDetails(){
		List<LoanApplicationModel> loanList=aService.getLoanDetails();
		return loanList;
	}
	
	@GetMapping("/searchLoanDetails/{LoanId}")
	public LoanApplicationModel searchLoanDetails(@PathVariable("LoanId") int loanId){
		return aService.searchLoanDetails(loanId);
	}
	
	@PostMapping("/saveLoanDetails")
	public LoanApplicationModel saveLoanDetails(@RequestBody LoanApplicationModel la) {
		return aService.saveLoanDetails(la);
	}
	
	@PutMapping("/updateLoanDetails/{LoanId}")
	public LoanApplicationModel updateLoanDetails(@RequestBody LoanApplicationModel la,@PathVariable int loanId) {
		return aService.updateLoanDetails(la,loanId);
	}
	
	@DeleteMapping("/deleteLoanDetails/{LoanId}")
	public void deleteLoanDetails(@PathVariable("LoanId") int loanId){
		aService.deleteLoanDetails(loanId);
	}
}
